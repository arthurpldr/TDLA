Rendu TP01 : 
-Athur Plomdeur
-Mahdi Khaled

Travail fait:
****Questions 1et2**** :
-importation des fichiers et création d'un main 
****Question 03******* :
-méthode boolean accept(String x) complété avec succès 
****Question 04******* :
-Affichage du DFA1.json à l'aide de la méthode toString
-Test de la méthode accept(String x) sur les mots du fichier Test.txt, la méthode fonctionne correctement OK pour les mots acceptés, 
 KO pour le cas contraire
****Question 05******** :
Création d'une classe NFA en modifiant les attributs de DFA ( implémentation des SET<> pour tenir compte de plusieurs états).
****Question 06******** :
Création des méthodes: 
-Set<State> applyDeltaTilde(Transition<Set<State>> t)
-accept(String x)
Pour le fichier NFA ainsi que des tests sur le fichier NFA.json à l'aide des mots fournis dans le fichier test.txt
effectués avec succés.


*********Automates testés************ :
-DFA question 3 et 4
-NFA question 5 6 et 7 




