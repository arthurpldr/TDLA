import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class NFA extends FSM {

	//Multiples etats de depart
	//à la place d'avoir des start et delta comme un DFA, on les modifie en setstate pour avoir plusieurs etats initiaux et transitions.
    private Set<State> starts;

    public State getStart() {
        return (State) starts;
    }

    // Fonction de Transititon
    //ici aussi, setstate à la place de state.
    private Map<Transition<State>, Set<State>> delta;

    public Map<Transition<State>, Set<State>> getDelta() {
        return delta;
    }

    // Constructeur par dÃ©faut
    //là aussi, mêmes modifications que les transitions et etats de departs.
    public NFA(Set<State> _states,
               Set<Symbol> _alphabet,
               Set<State> _start,
               Set<State> _ends,
               Map<Transition<State>, Set<State>> _delta) {

        super(_states, _alphabet, _ends);
        this.starts = _start;
        delta = _delta;
    }

    // Constructeur par fichier
    public NFA(String path) {
        super(path);
        Object obj = null;
        try {
            obj = new JSONParser().parse(new FileReader(path));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JSONObject jo = (JSONObject) obj;

        starts = new HashSet<State>();
        JSONArray jas = (JSONArray) jo.get("starts");
        //JSON
        for (Object o : jas) {
            State p = new State((String) o);
            starts.add(p);
            System.err.print(this.getStates().contains(p) ? "" : "Image starts " + p.toString() + "\n");
        }


        JSONArray ja = (JSONArray) jo.get("delta");

        delta = new HashMap<Transition<State>, Set<State>>();

        for (Object _o : ja) {

            JSONObject _jo = (JSONObject) _o;

            State q = new State((String) _jo.get("state"));
            System.err.print(this.getStates().contains(q) ? "" : "Ã‰tat " + q.toString() + " âŠ„ Q\n");

            Symbol a = new Symbol((String) _jo.get("symbol"));
            System.err.print(this.getAlphabet().contains(a) ? "" : "Symbole " + a.toString() + " âˆ‰ âˆ‘\n");

            Transition<State> t = new Transition<State>(q, a);
            JSONArray ji = (JSONArray) _jo.get("images");
            HashSet<State> s = new HashSet<State>();
            for (Object o : ji) {
                State p = new State((String) o);
                s.add(p);
                System.err.print(this.getStates().contains(p) ? "" : "Image " + p.toString() + " âŠ„ Q\n");
                delta.put(t, s);
            }

        }

    }

    //@Override
    @Override
    public String toString() {

        String buffer="[";
        for(State state : this.starts)
        {
            buffer= buffer+ state.getName() +", "; //ici modifie
        }
        buffer += "] \n ";
        return super.toString() +
                "s = " + buffer + "\n" +
                "ẟ = \n" + delta.toString().replaceAll("(\\{)|(\\})", "")
                .replace(", ", "\n")
                .replace("(", "   (");
    }


    public Set<State> applydelta(Transition t) {

        return delta.get(t)!=null? delta.get(t) : new HashSet<State>();
    }

    public Set<State>  applyDeltaTilde(Transition<Set<State>> t) {
    	// On instancie ici notre state et notre symbol ainsi que un iterateur.
        Set<State> elem = t.getP();
        Symbol sym = t.getA();
        Set<State> rt = new HashSet<>();
        Iterator<State> iterateur = elem.iterator();
        
        while(iterateur.hasNext()) {

            Iterator<State> it = applydelta(new Transition<State>(iterateur.next(),sym)).iterator();

            while(it.hasNext()) rt.add(it.next());
        }
        System.out.println(rt);

        return rt;
    }

    public boolean accept(String x) {
    	//Ici, on instancie un setstate pour y stocker nos etats de depart, puis en parcourant le mot, y stocker chaque etats.
        Set<State> current = this.starts;

        
        // on fait une boucle pour parcourir le mot que l'on teste
        for(char c : x.toCharArray()) {

            current  = applyDeltaTilde(new Transition<Set<State>>( current, new Symbol(""+c+"")));

        }
        //si current possede au moin 1 element qui est un state de fin, nous validons le mot
        for (State elem : current) {
            if (this.getEnds().contains(elem) )return true;
        }
        return false;
    }




}

