public class Main {

    public static void main (String[]args){
       
       /**Création d'un fichier DFA  et affichage à l'aide de toString*/ 
       DFA AUTO=new DFA("DFA1.JSON");
       System.out.println(AUTO.toString());

       /** test méthode accept dans DFA  */       
       DFA aut= new DFA("DFA1.JSON");
       if(aut.accept("abab")){
           System.out.println("OK POUR DFA");}
       else System.out.println("KO POUR DFA");

       /**Création d'un fichier NFA  et affichage à l'aide de toString*/
       NFA AUT2= new NFA("NFA1.json");
       System.out.println(AUT2.toString());
 
      /** test méthode accept dans NFA */
       if(AUT2.accept("aabb")){
           System.out.println("TRUE POUR NFA");
       }
       else System.out.println("FALSE POUR NFA");

    };

